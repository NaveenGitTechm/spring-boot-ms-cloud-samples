package com.demo.app.ws.exceptions;

public class UserServiceException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4067520825210339258L;
	
	public UserServiceException(String message) {
		super(message);
	}

}
