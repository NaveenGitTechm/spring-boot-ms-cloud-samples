package com.demo.app.ws.userservice.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.app.ws.common.Utils;
import com.demo.app.ws.ui.model.request.UserDetails;
import com.demo.app.ws.ui.model.response.UserRest;
import com.demo.app.ws.userservice.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	Map<String, UserRest> users;
	Utils utils;
	
	public UserServiceImpl() {
		
	}
	
	@Autowired
	public UserServiceImpl(Utils utils) {
		this.utils = utils;
	}
	
	@Override
	public UserRest createUser( UserDetails userDetails) {
		UserRest userRest = new UserRest();
		userRest.setFirstName(userDetails.getFirstName());
		userRest.setLastName(userDetails.getLastName());
		userRest.setEmail(userDetails.getEmail());
		
		String userId = utils.generateUserId();
		userRest.setUserId(userId);
		if( users == null ) users = new HashMap<>();
		users.put(userId, userRest);
		return userRest;
	}
}
