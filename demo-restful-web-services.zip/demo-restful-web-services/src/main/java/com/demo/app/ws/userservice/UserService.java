package com.demo.app.ws.userservice;

import com.demo.app.ws.ui.model.request.UserDetails;
import com.demo.app.ws.ui.model.response.UserRest;

public interface UserService {
	UserRest createUser( UserDetails userDetails);
}
