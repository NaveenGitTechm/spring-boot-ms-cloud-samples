package com.myapps.photoapp.users.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.myapps.photoapp.users.dto.UserDto;

public interface UserService extends UserDetailsService{
	UserDto createUser(UserDto userDetails);
	UserDto getUserDetailsByEmail(String email);
}
